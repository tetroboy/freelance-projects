#include "Prog7_functions.h"
#define MAXROW 5
#define MAXCOL 10
void ClearGrid(char (*arr)[10]){
for(int i = 0;i < MAXROW;i++){
    for(int j = 0;j< MAXCOL;j++){
        arr[i][j] = ' ';
    }
}
printf("Grid cleared\n\n");
}
void PrintGrid(char (*arr)[10]){ // fuction which printing our 2d array
    printf(" 0123456789\n"); // printing column counter
for(int i = 0;i < MAXROW;i++){
        printf("%d",i); // printing row counter
    for(int j = 0;j< MAXCOL;j++){
        printf("%c",arr[i][j]); //printing array
    }
    printf("\n");
}
printf("\n");
}
void FillGrid(char (*arr)[10],char a){ //function which fill our 2d array with 1 symbol
for(int i = 0;i < MAXROW;i++){
    for(int j = 0;j< MAXCOL;j++){
        arr[i][j] = a; //changing every element of our array on symbol
    }
}
printf("Grid filled with %c\n\n",a); // printing information for user
}
void SetRow(char (*arr)[10],char *buffer,int index){ // function which write users string to our grid in row
    if(index > 4 || index < 0){
        printf("Invalid row index %d\n",index); // if user input invalid row index printing error
    }
    else{
        for(int i = 0;i < MAXCOL; i++){
            if(i == strlen(buffer)) break; // writing only symbols which were inserted and no more than row length
            arr[index][i] = buffer[i];
        }
        printf("Set row %d\n\n",index); // printing information for user
    }
}
void SetCol(char (*arr)[10],char *buffer,int index){ // function which write users string to our grid in column
    if(index > 9 || index < 0){
        printf("Invalid col index %d\n",index); // if user input invalid column index printing error
    }
    else{
        for(int i = 0;i < MAXROW; i++){
            if(i == strlen(buffer)) break; // writing only symbols which were inserted and no more than column length
            arr[i][index] = buffer[i];
        }
        printf("Set col %d\n\n",index); // printing information for user
    }
}
void GetCol(char (*arr)[10],int index){ //function which printing column from our grid
if(index > 9 || index < 0){
        printf("Invalid col index %d\n",index); // if user input invalid column index printing error
    }
    else{
            printf("Col %d:",index);
        for(int i = 0;i < MAXROW; i++){
            printf("%c",arr[i][index]); // printing all column by 1 element
        }
        printf("\n\n");
    }

}
void GetRow(char (*arr)[10],int index){//function which printing row from our grid
if(index > 4 || index < 0){
        printf("Invalid row index %d\n",index); // if user input invalid row index printing error
    }
    else{
            printf("Row %d:",index);
        for(int i = 0;i < MAXCOL; i++){
            printf("%c",arr[index][i]); // printing all row by 1 element
        }
        printf("\n\n");
    }

}
int FindWord(char (*arr)[10],char *buffer){ //function which is searching string in every row and column in our 2d array
    char temp[5]; // array for columns
    char *istr;
int u = -1;
for(int i = 0; i < MAXROW;i++){
        u++;
        istr = strstr(arr[i],buffer); // checking every row
    if( istr == NULL){ // if word not find continue searching

        continue;
    }
    else {
        printf("Found the string %s in row #%d!\n\n",buffer,u); //if find word printing row number
        return 0;
    }
}

for(int i = 0;i < MAXCOL;i++){
    for(int j = 0;j < MAXROW;j++){
        temp[j] = arr[j][i]; //write column in temporary array
    }
    if(strstr(temp,buffer) != NULL){ // checking every column
        printf("Found the string %s in column #%d!\n\n",buffer,i); //if find word printing row number
        return 0;
    }
}
printf("%s was not found :(\n\n",buffer); // if not find word printing it
return 0;
}
void menu(){ // function which do communication with user
    char buffer[255]; //array for users input
    char a[5][10]; // our 2d array
    int index = 0;
    char elem; //element for function fillgrid
    char c[20]; //array for users commands
    while(1){ //infite loop
    printf("What do you want to do?");
    scanf("%s",&c); // scaning command from user and do what user want
    if(strcmp(c,"clear") == 0){
        ClearGrid(a);
    }
    else if(strcmp(c,"print") == 0){
        PrintGrid(a);
    }
    else if(strcmp(c,"fill") == 0){
        getchar();
        scanf("%c",&elem); //scaning element for fillgrid function
        FillGrid(a,elem);
    }
    else if(strcmp(c,"setrow") == 0){
        getchar();
        scanf("%s",&c); //scaning row index for setrow function
        index = atoi(c); // converting from string to int
        getchar();
        scanf("%s",&buffer);//scaning word for setrow function
        SetRow(a,buffer,index);
    }
    else if(strcmp(c,"setcol") == 0){
        getchar();
        scanf("%s",&c); //scaning column index for setcol function
        index = atoi(c);// converting from string to int
        getchar();
        scanf("%s",&buffer); //scaning word for setcol function
        SetCol(a,buffer,index);
    }
    else if(strcmp(c,"getrow") == 0){
        getchar();
        scanf("%s",&c); //scaning column index for getcol function
        index = atoi(c);// converting from string to int
        GetRow(a,index);
    }
    else if(strcmp(c,"getcol") == 0){
        getchar();
        scanf("%s",&c); //scaning row index for getrow function
        index = atoi(c);// converting from string to int
        GetCol(a,index);
    }
    else if(strcmp(c,"find") == 0){
        getchar();
        scanf("%s",&buffer); //scaning word which user want to find
        FindWord(a,buffer);
    }
    else if(strcmp(c,"quit") == 0){
        printf("Bye!");
        break; // end of loop
    }
    else{
        printf("Unrecognized command %s!\n\n",c);
    }
    }



}
