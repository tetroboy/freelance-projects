#pragma once
#include <stdio.h>
#include <stdlib.h>

void ClearGrid(char (*arr)[10]);
void PrintGrid(char (*arr)[10]);
void FillGrid(char (*arr)[10],char a);
void SetRow(char (*arr)[10],char *buffer,int index);
void SetCol(char (*arr)[10],char *buffer,int index);
void GetRow(char (*arr)[10],int index);
void GetCol(char (*arr)[10],int index);
int FindWord(char (*arr)[10],char *buffer);
void menu();
