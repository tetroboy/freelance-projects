#include <iostream>
#include <iomanip>
#include <cctype>
#include <cstring>

using namespace std;
//function prototypes
int CountVowels(char* arr, int lengh);
int CountPunctCharacters(char* arr, int lengh);
int CountWords(char* arr, int lengh);
bool IsWordInString(char* word, const char* str, int lengh_word, int lengh_string);
void AllLowercase(char* arr, int lengh);
void WordLenghCounter(int* counter_arr, const char* str, int lengh);

int main(){
    int flag1 = 1; //declaration of variables
    int flag2 = 0;
    int counter_arr[21];
    for(int i = 0; i < 21; i++){
        counter_arr[i] = 0;
    }
    char line[255];
    char word[20];
    char check[255];
    int flag = 0;
    while(flag1 == 1){ // menu loop
    cout << "Enter a sentence: ";
    cin.get(line,255); //reading line from user
    cin.ignore();//clearing input buffer
    cout << "Enter a word: " ;
    cin.get(word, 20);//reading word from user
    //printing sentence analys
    cout << endl <<  "SENTENCE ANALYSIS" << endl << endl;
    cout << "Punctuation Characters: " << CountPunctCharacters(line,strlen(line)) << endl;
    cout << "Vowels: " << CountVowels(line,strlen(line)) << endl;
    cout << "Words: " << CountWords(line,strlen(line)) << endl << endl;
    WordLenghCounter(counter_arr,line,strlen(line));
    for(int i = 1;i < 21; i++){ //loop for printing word counters
        if(counter_arr[i] != 0 && counter_arr[i] == 1) cout << i << " characters long: " << counter_arr[i] << " word" <<endl;
        else if(counter_arr[i] != 0 && counter_arr[i] > 1) cout << i << " characters long: " << counter_arr[i] << " words" <<endl;
    }
    cout << endl;
    if(IsWordInString(word,line,strlen(word),strlen(line))) cout << "The word: \"" << word << "\"IS part of the sentence you entered." << endl;
    else cout << "The word: \"" << word << "\"IS NOT part of the sentence you entered." << endl;
    cout << "Enter another sentence/word for analysis (yes/no): ";
    while(flag2 == 0){ //loop for checking if user entered yes or no
        cin.ignore();
        cin >> check;
        AllLowercase(check,strlen(check));
        if(!strcmp(check,"yes")){ //using cstring function to check if check == "yes"
            flag2 = 1;
            flag1 = 1;
            cin.ignore();
        }
        else if(!strcmp(check,"no")){
            flag2 = 1;
            flag1 = 0;
            cin.ignore();
        }
        else cout << "Enter yes or no: ";
    }
    flag2 = 0;

    }

    return 0;
}

int CountVowels(char* arr, int lengh){ // function to count vowels
    int counter = 0;
    for(int i = 0; i < lengh; i++){
        if(arr[i] == 'u' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'U' || arr[i] == 'I' || arr[i] == 'O' || arr[i] == 'A' || arr[i] == 'E') counter++;
    } //if member of arr is vowel we add 1 to counter
    return counter;
}

int CountPunctCharacters(char* arr, int lengh){
    int counter = 0;
    for(int i = 0; i < lengh; i++){
        if(ispunct(arr[i])) counter++; //same as vowels function, using here cctype function ispunct which check is symbol is a punctuation symbol
    }
    return counter;
}

int CountWords(char* arr, int lengh){
    int counter = 0;
    for(int i = 0; i < lengh; i++){
        if((isalpha(arr[i-1]) || isdigit(arr[i-1])) && i > 0 && isspace(arr[i])) counter++;
        else if(i+1 == lengh && isprint(arr[i])) counter++;
        //else if(isdigit(arr[i-1]) && i > 0 && isspace(arr[i])) counter++;
    }
    return counter;
}

bool IsWordInString(char* word, const char* str, int lengh_word, int lengh_string){//checking if word in string
    bool flag = 0;
    for(int i = 0; i < lengh_string ; i++){
        if(str[i] == word[0]){ //finding first letter of word in line
            for(int j = 1; j < lengh_word; j++){
                if(str[i+j] == word[j] && (j+i < lengh_string)) flag = 1;
                //finding other letters
                else{
                  flag = 0; //end loop if letter don`t match
                  break;
                }
            }
        }
        if(flag == 1) return 1; //return true if we find word
    }
    return 0;
}

void AllLowercase(char* arr, int lengh){ //do all members of arr lowercase
    for(int i = 0; i < lengh; i++) if(isalpha(arr[i])) arr[i] = tolower(arr[i]);
} //isalpha function from cctype checking we have letter and after it function tolower make it lowercase

void WordLenghCounter(int* counter_arr, const char* str, int lengh){ //counting words of each lengh
    int counter = 0;
    for(int i = 0; i < lengh; i++){
        if((isalpha(str[i]) || isdigit(str[i])) && (isspace(str[i-1]) && i > 0) || i == 0){
            for(int j = 0; j < lengh-i; j++){
                if(isalpha(str[i+j]) || isdigit(str[i+j]) || ispunct(str[i+j])){
                    counter++; //if we find a letter we start to count untill we find space and after it we add 1 to arr of counters at index which same as word lengh
                }
                else break;
            }
            counter_arr[counter]++;
            counter = 0;
        }
    }
}
