#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

/*Given Global CONST variables representing MIN and MAX boundaries for array usage. The user will specify a size
between MIN and MAX to specify the "current size", aka, the portion of the array that is "in use".
The amount of the array "in use" can then grow up to MAX and can shrink down to MIN.
Use these variables throughout your program whenever referring to the array's MAX and MIN size bounds*/
const int MAX = 100;
const int MIN = 10;

/*Function prototypes*/
void menu(int *arr); //prototype of menu function
void FillArrayRandomNumber(int min, int max,int *arr, const int size); //prototype of Random fill function
void ReverseArray(int *arr, const int size); //prototype of function which is reversing array
void Shift(int *arr, const int size, int index); //prototype of function which shifts right
void InsertInArray(int *arr, const int size, int value_to_insert, int index); //prototype of function of inserting elements in array
void DeleteFromArray(int *arr, const int size, int index); //prototype of function which deleting elements from array
int FindMax(const int arr[], const int size); //prototype of function which finding maximum value in array
double FindArrayAverage(const int arr[], const int size); //prototype of function which finding average value of array
void GrowArraySize(int *size); //prototype of function which grows up array
void ShrinkArraySize(int *arr, int *size); //prototype of function which shrinks up array
void PrintArray (const int arr[], const int size);
void PrintMenu(); //prototype of function which recalling menu
void BubbleSort(int *arr, const int size); //prototype of bubblesort function

int main()
{
	int list[MAX]; //creation of array named list, with allocated size MAX.
	for(int i = 0; i < MAX ; i++){ // pre-initializing array list with 0
        list[i] = 0;
	}
    menu(list); //calling function menu

        // rest of program

	return 0;
}


/*Function Definitions*/

void menu(int *arr){ //function for testing work of programm
    int arr_size, value_to_insert, index;
    /*variables (arr_size - current array size
    value_to_insert - buffer for insert fuction*/
    while(1){ //endless loop
    cout << "Enter a value " << MIN << " --> " << MAX << ": ";
    cin >> arr_size; //reading value from user
    if( arr_size < MIN || arr_size > MAX) cout << " You inputed wrong size " << endl; //check of inputed value
    else break; //if value is ok, ends a while loop
    }
    char char_var; // variable for switch

    PrintMenu(); //calling function to print a possible actions
    while(1) //endless loop
    {
        cout << "Selection > ";
        cin >> char_var; //reading value from user
        if(char_var < 123 && char_var > 96) char_var -= 32;
        //if user writes a lowercase letter it will became uppercase and both variants will work(2 extra pts task)

        if((char_var == 'Q') || (char_var == 'q')) break; //if user print Q or q program loop will end and program will stop


        switch(char_var) //switch statement which use variable char_var
        {
           case 'F':{ //if variable char_var = 'F' or 'f' this will happen
               FillArrayRandomNumber(1,100, arr, arr_size); //calling function to fill array with random integers
               cout << "Randomizing Array Data..." << endl << endl; //endl is a new line(endline)
               break; // end of case block
           }
           case 'R':{ //if variable char_var = 'R' or 'r' this will happen
               ReverseArray(arr, arr_size); //calling function to reverse array
               cout << "Reversing Array..." << endl << endl;
               break;
           }
           case 'X':{ //if variable char_var = 'X' or 'x' this will happen
               cout << "Shift right by: ";
               cin >> index; //reading index for shift function
               Shift(arr, arr_size, index); //calling shift function
               break;
           }
           case 'I':{ //if variable char_var = 'I' or 'i' this will happen
               cout << "Value to insert? > ";
               cin >> value_to_insert; //reading variable for insert fuction
               cout << "At which index? > ";
               cin >> index; //reading index for insert function
               if(index >= 0 && index < arr_size){ //checking index(array have element with such index)
                    cout << "Inserting " << value_to_insert << " at list[" << index << "]" << endl << endl;
                    InsertInArray(arr, arr_size, value_to_insert, index);//calling an insert function
               }
               else cout << "Cannot insert value" << " at list[" << index << "], out of bounds" << endl << endl;
               //if received invalid index ends a case block without calling a function
               break;
           }
           case 'D':{ //if variable char_var = 'D' or 'd' this will happen
               cout << "At which index? > ";
               cin >> index; //reading index for delete function
               if(index >= 0 && index < arr_size){//checking index(array have element with such index)
                    cout << "Deleting element at index " << index << endl << endl;
                    DeleteFromArray(arr, arr_size, index);//calling a delete function
               }
               else cout << "Cannot delete value" << " at list[" << index << "], out of bounds" << endl << endl;
               //if received invalid index ends a case block without calling a function
               break;
           }
           case 'A':{ //if variable char_var = 'A' or 'a' this will happen
               cout << "Average: " << FindArrayAverage(arr, arr_size) << endl << endl; //calling of average function
               break;
           }
           case 'M':{ //if variable char_var = 'M' or 'm' this will happen
               cout << "Max value: " << FindMax(arr, arr_size) << endl << endl;
               break;
           }
           case 'G':{ //if variable char_var = 'G' or 'g' this will happen
               if(arr_size < MAX - 4 ){ //check that current array size lower than MAX value at least on 5 points
                   GrowArraySize(&arr_size); //calling grow function sending adress of variable(for changing it)
                   cout << "Array size is now: " << arr_size << endl << endl;
               }
               else{ //ends case block without calling function if current array size is > than max-4 value
                   cout << "Cannot Grow Array. Current Size: " << arr_size <<  " Maximum Size: " << MAX << endl << endl;
               }
               break;
           }
           case 'S':{ //if variable char_var = 'S' or 's' this will happen
               if(arr_size - 4 > MIN ){ //check that current array size greater than MIN value at least on 5 points
                   ShrinkArraySize(arr, &arr_size); //calling shrink function sending adress of variable(for changing it)
                   cout << "Array size is now: " << arr_size << endl << endl;
               }
               else{ //ends case block without calling function if current array size is < than min + 4 value
                   cout << "Cannot Shrink Array. Current Size: " << arr_size <<  " Minimum Size: " << MIN << endl << endl;
               }
               break;
           }
           case 'P':{ //if variable char_var = 'P' or 'p' this will happen
               PrintArray(arr, arr_size); //prints array
               break;
           }
           case 'W':{ //if variable char_var = 'W' or 'w' this will happen
               PrintMenu(); //prints menu
               break;
           }
           case 'Z':{ //if variable char_var = 'Z'or 'z' this will happen
               BubbleSort(arr, arr_size); //Sorting array with bublesort
               cout << "Sorting Array Data..." << endl << endl;
               break;
           }
           default:{ //if we have wrong input user will receive this message
               cout << "Invalid Selection" << endl << endl;
               break;
           }
        }
    }
}

void FillArrayRandomNumber(int min, int max, int *arr, const int size)
{

    for(int i = 0; i < size; i++){
        arr[i] = min + rand() % (max - min + 1); //randomising algorithm for our array

    }

}

void ReverseArray(int *arr, const int size){
    int buffer; //temporary variable

    for(int i = 0; i < size/2; i++){ //algorithm for reversing an array(going to a half of a size because we will receive the same array if use all size)
        buffer = arr[i];
        arr[i] = arr[size - i - 1];
        arr[size - i - 1] = buffer;
    }//swapping first with last, second with prelast...
}

void Shift(int *arr, const int size, int index){
    int buffer;
    for(int i = 0; i < index; i++){ // first loop which is counts amount of shifts
        buffer = arr[size - 1]; //last element in array now in buf
        for(int j = size - 1;j > 0 ;j--){ //from prelast to first
            arr[j] = arr[j-1]; //moving elements forward for 1 index
        }
        arr[0] = buffer; // first element of array is clear now so we put last one on it place
    }
}

void InsertInArray(int *arr, const int size, int value_to_insert, int index){ arr[index] = value_to_insert; } // insert value in current array index

void DeleteFromArray(int *arr, const int size, int index){
    arr[index] = 0; //deleting from array
    int buffer;
    for(int i = index; i < size-1; i++){//moving deleted value to the end of array
        buffer = arr[i + 1];
        arr[i + 1] = arr[i];
        arr[i] = buffer;
    }
}


int FindMax(const int arr[], const int size){ // we have int type of function because we returning an int variable
    int max_value = 0;//temporary variable
    for(int i = 0; i < size; i++){
        if(arr[i] > max_value) max_value = arr[i]; // if array value is greater than current max value, max value becomes array value in current index
    }
    return max_value;
}

double FindArrayAverage(const int arr[], const int size){
    int buffer = 0;//variable for sum of all array members
    for(int i = 0; i < size; i++) buffer += arr[i]; //summing all array integers
    return (buffer * 1.0) / (size * 1.0); //calculating average of array but making double variables from integers by * 1.0
}


void GrowArraySize(int *size){ *size += 5;} //increasing original size of array on 5(doing manipulations with variable not with copy)

void ShrinkArraySize(int *arr, int *size){
    *size -= 5;
    for(int i = *size; i < *size + 5; i++) arr[i] = 0; //deleting elements from shrinked array
} //decreasing original size of array on 5


//GIVEN: PrintArray Function Definition
//This function prints the contents of an integer array of any size, separated by commas
void PrintArray(const int arr[], const int size)
{
	cout << "\nThe array:\n { ";
	for (int i = 0; i < size-1; i++)	// for loop, prints all items except last with commas
		cout << arr[i] << ", ";

	cout << arr[size-1] << " }\n\n";	// prints last item , no comma
}

void PrintMenu(){ //function which prints menu bar
    cout << "-------------------MENU-------------------" << endl;
    cout << "F - Fill Array: RANDOM values 1 - 100" << endl;
    cout << "R - Reverse Array Contents" << endl;
    cout << "X - Shift Right" << endl;
    cout << "I - Insert Array Element" << endl;
    cout << "D - Delete Array Element" << endl;
    cout << "A - Print Average" << endl;
    cout << "M - Print Max Value" << endl;
    cout << "G - Grow Array Size by 5" << endl;
    cout << "S - Shrink Array Size by 5" << endl;
    cout << "P - Print Array" << endl;
    cout << "W - Print menu" << endl;
    cout << "Z - Sort Array" << endl;
    cout << "Q - QUIT" << endl;
    cout << "------------------------------------------" << endl;
}

void BubbleSort(int *arr, const int size){ //BubbleSorting function(each element compares with other in array and sorted from lover to higher)
    int buffer;
    for(int i = 0; i < size; i++){
        for(int j = 0; j < size - 1; j++){
            if(arr[j] > arr[j + 1]){
                buffer = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = buffer;
            }
        }
    }
}


